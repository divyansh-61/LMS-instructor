import { Component } from '@angular/core';

@Component({
  selector: 'app-success-delete-popup',
  templateUrl: './success-delete-popup.component.html',
  styleUrls: ['./success-delete-popup.component.css']
})
export class SuccessDeletePopupComponent {

}
