import { Component } from '@angular/core';

@Component({
  selector: 'app-product-message-to-reviewer',
  templateUrl: './product-message-to-reviewer.component.html',
  styleUrls: ['./product-message-to-reviewer.component.css']
})
export class ProductMessageToReviewerComponent {

}
